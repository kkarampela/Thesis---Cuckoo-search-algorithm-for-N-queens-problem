function [best_nest_discrete, fmax]=cuckoo_search_my(N)
% N : population size, n*n, number of queens,
%     Dimensions of the problem.
% p : result of randperm. Initial positions of queens.
% p_cont : p transformed from discrete to continuous.
% pa : 0.25 probability
% L : penalties
    
    % ToDo: check different numbers for population size.
	n = 100;            % Population size. Number of possible solutions.
	pa = 0.25;             % Discovery rate of alien eggs/solutions

    %% Simple bounds of the search domain
    % ToDo: check again the boundaries. Checked ! No better bounds 
    Lb = -5*ones(1, N);     % Lower bounds
    Ub = 5*ones(1, N);      % Upper bounds

    nest = zeros(n, N);
    % Random initial solutions
    for i = 1:n,
        p = randperm(N);
        nest(i, :) = discrete_to_continuous(p);
    end
    
    % Get the current best of the initial population
    fitness = -inf*ones(n, 1);

    foptimal = objective_function(N, 0);

    [fmax, bestnest, nest, fitness] = get_best_nest(nest, nest, fitness);
    % Generate new solutions (but keep the current best)
    new_nest = get_cuckoos(nest, bestnest, Lb, Ub);   
    [fnew, best, nest, fitness] = get_best_nest(nest, new_nest, fitness);
    % Discovery and randomization
    new_nest = empty_nests(nest, Lb, Ub, pa);
    % Evaluate this set of solutions
    [finit, best, nest, fitness] = get_best_nest(nest, new_nest, fitness);
    % finit: fitness of best solution (nest)
    % best: best solution (nest)
    % nest: set of best solution (nest)
    % fitness: set of fitness of best solution (nest)

    nest_init = continuous_to_discrete(best);
    
    disp(strcat('The best solution after cuckoos algorithm = ' ));
     disp(num2str(nest_init));
    disp(strcat('The fmax after cuckoos algorithm = ', num2str(finit)));
    disp(strcat('The foptimal after cuckoos algorithm = ', num2str(foptimal)));

    
    % o elegxos gia to an o algotihmos exei vrei veltisti timi ( foptimal kateytheian )
    if finit == foptimal
        fmax = finit;
        best_nest_discrete = nest_init;
    else
        %call iterated local search 
        %conflict queens=tsekarw tis theseis twn basilisswn pou trakaroun 
        [L_new, conflict_queens] = penalties(N, nest_init);
        [nest_ex, fex] = exchange(N, nest_init, finit, conflict_queens);   %kalw thn exchange

        fmax = fex;
        best_nest_discrete = nest_ex;

    end

end



%% Find the current best solution/nest among the population
function [fmax, best, nest, fitness]=get_best_nest(nest, newnest, fitness)

    N = size(nest, 2);
    % Evaluating all new solutions
    for j = 1:size(nest, 1),
        % ginetai discrete giati to penalties leitoyrgei me diakrites times 
        newnest_disc = continuous_to_discrete(newnest(j, :));
        [L_new, conflict_queens] = penalties(N, newnest_disc);
        fnew = objective_function(N, L_new);

        foptimal = objective_function(N, 0);
        %H fnew prepei na einai >= ths fitness Kai veltista = me foptimal
        if fnew >= foptimal,
            fitness(j) = fnew;
            nest(j, :) = newnest(j, :);
            break;
        elseif fnew >= fitness(j),
            fitness(j) = fnew;
            nest(j, :) = newnest(j, :);
        end
    end

    % Find the current best
    [fmax, K] = max(fitness);
    best = nest(K, :);
    %disp(K);
    %disp(best);
    %disp( max(fitness)); 
end




%% Get cuckoos by random walk - Levy Flights 
function nest=get_cuckoos(nest,best,Lb,Ub)
    
    % Levy flights
    n = size(nest, 1);
    
    beta = 3/2;
    sigma = (gamma(1+beta)*sin(pi*beta/2)/(gamma((1+beta)/2)*beta*2^((beta-1)/2)))^(1/beta);
    
    for j = 1:n,
        s = nest(j,:);
        % This is a simple way of implementing Levy flights
        % For standard random walks, use step = 1;
        %% Levy flights by Mantegna's algorithm
        u = randn(size(s))*sigma;
        v = randn(size(s));
        step = u./abs(v).^(1/beta);
      
        % In the next equation, the difference factor (s-best) means that 
        % when the solution is the best solution, it remains unchanged.     
        stepsize = 0.01*step.*(s-best);
        % Here the factor 0.01 comes from the fact that L/100 should be the
        % typical step size for walks/flights where L is the problem scale; 
        % otherwise, Levy flights may become too aggresive/efficient, 
        % which makes new solutions (even) jump out side of the design domain 
        % (and thus wasting evaluations).
        % Now the actual random walks or flights
        s = s+stepsize.*randn(size(s));
        % Apply simple bounds/limits
        nest(j,:) = simplebounds(s,Lb,Ub);
    end
end

%% Replace some not-so-good nests by constructing new solutions/nests
function new_nest=empty_nests(nest,Lb,Ub,pa)
    % A fraction of worse nests are discovered with a probability pa
    n = size(nest,1);
    % Discovered or not -- a status vector
    K = rand(size(nest))>pa;
   
    % Notes: In the real world, if a cuckoo's egg is very similar to 
    % a host's eggs, then this cuckoo's egg is less likely to be discovered. 
    % so the fitness should be related to the difference in solutions.  
    % Therefore, it is a good idea to do a random walk in a biased way 
    % with some random step sizes.  
    %% New solution by biased/selective random walks
    stepsize = rand*(nest(randperm(n),:)-nest(randperm(n),:));
    new_nest = nest+stepsize.*K;
    for j = 1:size(new_nest,1)
        s = new_nest(j,:);
        new_nest(j,:) = simplebounds(s,Lb,Ub);  
    end
end

% Application of simple bounds/constraints
function s=simplebounds(s,Lb,Ub)
    % Apply the lower bound
    ns_tmp=s;
    I=ns_tmp<Lb;
    ns_tmp(I)=Lb(I);

    % Apply the upper bounds 
    J=ns_tmp>Ub;
    ns_tmp(J)=Ub(J);
    % Update this new move 
    s=ns_tmp;
end

