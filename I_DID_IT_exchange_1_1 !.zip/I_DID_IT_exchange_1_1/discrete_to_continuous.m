function [ p ] = discrete_to_continuous( p )

%input p 
% Find the maximum value of p.
A=max(p);
%divide each element of p with the maximum value  
p=(p/A);

end

