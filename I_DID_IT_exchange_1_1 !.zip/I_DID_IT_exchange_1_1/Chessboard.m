function Chessboard(N)
%Function creates a chessboard plot
%Input

if mod(N,2) %Creating an array of 1s and 0s
    a = ones(N);%creating an array with 1s
    a(2:2:N*N) = 0; %every 2nd cell placing  0 
else
    a = ones(N+1,N);
    a(2:2:(N+1)*N) = 0;
    a(N+1,:)=[];
end

imagesc(a) %Creates an image mapping of the matrix

colour=[0 0 0;1 1 1]; %Black and white colour mapping
colormap(colour) %Changes to black and white colour mapping

grid off
set(gca,'yticklabel',[],'xticklabel',[],'xtick',[],'ytick',[])

end