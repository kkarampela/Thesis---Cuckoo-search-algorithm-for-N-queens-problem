function [nest_new, fnew]=exchange(N, nest_init, finit, conflict_queens)

    num_conflict_queens = size(nonzeros(conflict_queens), 1) / 2;

    % create an array with each possible solution
    fitnesses = zeros(N, 1);
    nests = zeros(N);
   % disp(conflict_queens);
    for j = 1:num_conflict_queens

        con_queen = conflict_queens(1, 1);
        if con_queen == 0
            break;
        end

        % fill the array with the initial solution
        fitnesses(con_queen) = finit;
        nests(con_queen, :) = nest_init;

        % fill the array with each possible solution

        % search only downwards
        if con_queen == 1
            % se auto to loop psaxnoume na vroume ola ta fitnesses
            for i = 2:N
                % efarmozoume tin antallagi kai upologizoume to fitness
                [nests(i, :), fitnesses(i)] = exchange_lines(N, nest_init, con_queen, i);
            end
        % search upwards and downwards
        else
            % se auto to loop psaxnoume na vroume ola ta fitnesses
            for i = 1:con_queen - 1
                % efarmozoume tin antallagi kai upologizoume to fitness
                [nests(i, :), fitnesses(i)] = exchange_lines(N, nest_init, con_queen, i);
            end
            for i = con_queen + 1:N
                % efarmozoume tin antallagi kai upologizoume to fitness
                [nests(i, :), fitnesses(i)] = exchange_lines(N, nest_init, con_queen, i);
            end
        end

        [fnew, i_fnew] = max(fitnesses);
        nest_new = nests(i_fnew, :);

        finit = fnew;
        nest_init = nest_new;

        [L_new, conflict_queens] = penalties(N, nest_new);

    end
    %emfanizontai oi times meta tin topiki anazitisi
    disp(strcat('The best solution after local search = '));
     disp(num2str(nest_new));
    disp(strcat('The fmax after local search = ', num2str(fnew)));
    disp(strcat('The foptimal after local search = ', num2str(objective_function(N, 0))));

end

