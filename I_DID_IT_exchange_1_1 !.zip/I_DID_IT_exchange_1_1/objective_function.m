function [O] = objective_function(N, L)

%This is the objective function of the problem

O=((N^2)/2)-L; 

end

