function [nest_new, fnew]=exchange_lines(N, nest, con_queen, i)

    % con_queen: poia vasilissa trakarei (grammi)
    % nest(con_queen): thesi tis vasilissas (stili)
    nest_new = nest;

    % ginetai antimetathesi twn grammwn.
    nest_new(con_queen) = nest(i);
    nest_new(i) = nest(con_queen);

    [L_new, con_queen_tmp] = penalties(N, nest_new);
    fnew = objective_function(N, L_new);

end

