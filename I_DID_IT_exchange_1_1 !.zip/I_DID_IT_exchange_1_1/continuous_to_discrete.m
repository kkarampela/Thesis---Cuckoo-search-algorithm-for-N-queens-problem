function [ p_disc ] = continuous_to_discrete( p_cont )

    % Calculate the size of p_cont.
    %vazoume size(p_cont, 2) giati theloume ti deuteri diastasi dld tis stiles 
    n = size(p_cont, 2);
    p_disc= zeros(1, n);
    
    for i=1:n
        %stin A,intex entoli pairnw rto mikrotero stixio kai ti thesi tou 
        [A, index] = min(p_cont);
        %sto p_disc(intex) mpainei i thesi stin opoia vrisketai to i-osto mikrotero  stoixeio  
        p_disc(index)=i;
        %vazoume sto stoixio poy idi tsekarame apeiri timi, wste na einai
        %ektos sunagonismou
        p_cont(index) = inf;
    end
end

