clear all;
close all;
clc;

N=input('Board Size/no.queens : ');

if mod(N, 1) == 0 && N > 0
%counter 
    tic

    if (N == 1)
        error('There is only one solution.');
    elseif (N==2 | N==3) %Problem unsolvable for size 2 or 3 
        error('Board must be minimum size of 4');
    end

    [p_cont_new, fmax] = cuckoo_search_my(N);
    disp(strcat('The best solution =  '  ));
    disp(num2str(p_cont_new));
    disp(strcat('The fmax = ', num2str(fmax)));
    disp(strcat('The foptimal = ', num2str(objective_function(N, 0))));


    toc 
     icon=char(9819); %Queen character for the plot
     
    Chessboard(N);
    text(p_cont_new, [1:N], icon,'Color',[0.522,0.376,0.702],'FontSize', 200/N,'HorizontalAlignment','Center') %Font size scaling found to be suitable
    
else
    error('N must be a positive integer.');
end

