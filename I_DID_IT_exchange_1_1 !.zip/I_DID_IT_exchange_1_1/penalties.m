function [L, conflict_queens] = penalties(N, p)
%PENALTIES Computes the penalty for N queens
    queens = zeros(N);
    for i = 1:N
        queens(i, p(i)) = 1;
    end
    L = 0;
    pairs = 0;
    for i = 1 : N
        pairs = pairs + N-i;
    end
    conflict_queens = zeros(pairs, 2);
    for i_q1 = 1:N-1
        Q1_row = i_q1;
        Q1_col = find(queens(i_q1, :) == 1);
        for i_q2 = (i_q1+1):N
            %vrisko ti vasilissa kai ti thesi tis 
            Q2_row = i_q2;
            Q2_col = find(queens(i_q2, :) == 1);
            %check ti diagonio 
            deltaRow = abs(Q1_row-Q2_row);
            deltaCol = abs(Q1_col-Q2_col);
            if deltaRow == deltaCol
                L = L + 1;
                conflict_queens(L, :) = [i_q1, i_q2];
            end
        end
    end
   
end


    